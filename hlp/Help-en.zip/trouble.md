# &#128295;Troubleshooting

## Only a blank page is displayed
It is probably because of [CORS restrictions][bypassCORS].

[bypassCORS]: corsPolicy.md "Browser possibly blocking local file access (file://) due to CORS policy restrictions"