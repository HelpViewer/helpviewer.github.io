# &#9881;&#65039;Features

## 📚 HelpViewer

- 📦 No installation required - just unzip and run locally
- &#129702; Lightweight - under 1.2 MiB, 12 files + 2 subfolders (most part of solution compressed)
- ⚖ MIT licensed

## 🟢 Works out of the box with a single Markdown file ...

- &#128187; Multiplatform - works on all major operating systems via web browsers
- 📴 Ready to work in offline mode without any backend or local server
  - 🟡 A browser with CORS policies disabled is recommended. Otherwise, functionality is partially limited and you must manually select the data file and help file at startup.
- 🧭 Simple user interface
- &#128241; Responsive (desktop and other devices supported)
- 🔲 Seamless full-screen expansion of topic content
- &#128278; Bookmarks for chapters supported
- &#127912; Four native color schemes: color (default), greyscale, white on black, and black on white
- &#9855; Accessibility rules WCAG 2.1 implemented (accessibilitychecker.org: 89 %, Lighthouse: 96%, [Web Aim][waverep])
- &#x1F4C4; Print friendly version (prefers greyscale)
- &#128172; Tooltips in English, Czech (other languages planned)

## 🚀 When help project is defined ...

- 📂 Hierarchical view of topics (collapsible topic tree)
- 📇 Linking glossary terms to relevant topics and files
- 🔎 Full-text search dictionary for chapter contents
- ⏭ Integrated topic navigation buttons

### 🛠️ The browser runs with CORS policies disabled ...
- 🌐 Easily switch between different language versions
- 🕘 Easily switch help file version (Internet connection required)

## 🗄️ Additional features when deployed on a server ...

- 🌐 Progressive Web Application (PWA), installable directly to your device for quick access
- ✅ For help files hosted on the same server as HelpViewer, CORS is no problem
- 🟡 For external resources, it depends on the correct CORS header settings on the server side

[waverep]: https://wave.webaim.org/report#/https://helpviewer.github.io "WAVE WebAim report"
