# &#9881;&#65039;Funkce

## 📚 HelpViewer

- 📦 Není nutná žádná instalace - jen rozzipujte a spusťte místní soubor (klidně i bez Internetu)
- 💾 Nízká velikost – pod 1,2 MB, 12 souborů a 2 podsložky (většina obsahu je zkomprimovaná)
- 🧩 Snadno použitelný systém pluginů a rozšiřitelná architektura
- 📥 Snadno nastavitelné hlavní funkce v přehledném stromovém zobrazení
- ⚖ Licence: MIT

## 🟢 Stačí jediný Markdown soubor i bez projektu nápovědy ...

- &#128187; Multiplatformní - pracuje na všech operačních systémech přes webový prohlížeč
- 📴 Může fungovat v offline režimu bez backendu nebo lokálního serveru
  - 🟡 Doporučený je prohlížeč s vypnutými CORS politikami. Jinak je funkčnost částečně omezená a při spuštění je nutné ručně vybrat datový soubor a soubor nápovědy.
- 🧭 Intuitivní uživatelské rozhraní
- &#128241; Responzivní web (podporuje desktop i mobilní zařízení)
- 🔲 Snadný přechod do full screen režimu pro zvětšení plochy prohlížené kapitoly
- &#128278; Podpora záložek pro podsekce v kapitole
- 🔎 Slovník pro fulltextové vyhledávání obsahu kapitol
- &#127912; 5 vestavěných barevných režimů: barva (výchozí), stupně šedi, bílá a černá, černá a bílá, sepie
- &#9855; Zohlednění přístupnosti – WCAG 2.1 (accessibilitychecker.org: 89 %, Lighthouse: 96%, [Web Aim][waverep])
- 🖨️ Verze vhodná pro tisk (upřednostňuje stupně šedi)
- 📚 Zobrazit všechny kapitoly jako jeden dokument
- &#128172; Bublinová nápověda prostředí v češtině a angličtině (plánují se další jazyky)
- 🌐 Snadné přepnutí jazykové verze prohlížeče
- 📽 Prezentační režim s navigací kapitol a snímků pomocí kláves šipek
- ✏️ Osobní poznámky u odstavců kapitol

## 🚀 Když je definován projekt nápovědy ...

- 📂 Hierarchický strom témat s možností otevírání a uzavírání složek
- 📇 Propojení pojmů s příslušnými kapitolami a soubory
- ⏭ Integrovaná tlačítka pro základní navigaci v nápovědě
- 🕘 Přepínání mezi verzemi nápovědy (je potřeba být připojen k Internetu)
- 🌐 Snadné přepnutí jazykové verze nápovědy

## 🗄️ Nasazením na server navíc ...

- 🌐 Progresivní webová aplikace (PWA) instalovatelná do zařízení jako odkaz
- ✅ Pro nápovědy hostované na stejném serveru jako HelpViewer je CORS bez problémů
- 🟡 U externích zdrojů nápověd záleží na správném nastavení CORS hlaviček na straně serveru

[waverep]: https://wave.webaim.org/report#/https://helpviewer.github.io "WAVE WebAim zpráva"
