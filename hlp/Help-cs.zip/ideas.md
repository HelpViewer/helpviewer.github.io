# 💡 Možné aplikace

- Systém nápovědy
- Systém znalostní báze
- Interaktivní dokumentace
- Studijní materiál nebo sylaby
- Elektronická kniha
- Klasická snímková prezentace
- Offline prezentace produktu nebo mikrostránka
- Osobní web
- Portfolio projektů
- Firemní intranet
- Digitální nástěnka
- Informační kiosek
