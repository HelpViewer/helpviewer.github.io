# &#128295;Řešení problémů

## Zobrazuje se jen prázdná stránka
Pravděpodobnou příčinou jsou [CORS omezení][bypassCORS].

[bypassCORS]: corsPolicy.md "Prohlížeč může blokovat přístup k místním souborům (file://) kvůli CORS politikám"