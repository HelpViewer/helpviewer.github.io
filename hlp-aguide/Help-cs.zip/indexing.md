# 🔎 Indexace kapitoly

Po vytvoření je vhodné kapitolu zapsat například do těchto seznamů:

- 📖 Strom témat (tree.lst)
- 📑 Seznam souborů (files.lst)
- 📇 Seznam klíčových slov (keywords.lst)
- 📇 Vazba mezi klíčovými slovy a soubory (keywords-files.lst)

V podkapitolách stromu jsou popsány vnitřní struktury těchto souborů.
