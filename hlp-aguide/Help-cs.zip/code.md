# 🧾 Kódový výpis

Pro HTML dokumenty zde v tomto není žádná podpora.

Výpis zdrojového kódu do **md** vložíte tímto způsobem:

````
```
Text Vašeho kódu
```
````

Ukázka:

```
Text Vašeho kódu
```
