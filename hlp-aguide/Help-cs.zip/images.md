# 🖼️ Obrázky

Obrázky do kapitoly vložíte tímto způsobem:

```
![popis když obrázek neexistuje](cesta/k/obrazku.png "Popisek obrázku pro bublinovou nápovědu")
```

Cesta k obrázku je buď:
  - místní uvnitř nápovědy:  
    ```
    cesta/k/obrazku.png
    ```
  - nebo vzdálená:  
    ```
    https://avatars.githubusercontent.com/u/214681531?s=200&v=4
    ```

Ukázka:

![popis když obrázek neexistuje](https://avatars.githubusercontent.com/u/214681531?s=200&v=4 "Popisek obrázku pro bublinovou nápovědu")

![popis když obrázek neexistuje (místní obrázek z nápovědy)](_icon.png "místní obrázek z nápovědy")
