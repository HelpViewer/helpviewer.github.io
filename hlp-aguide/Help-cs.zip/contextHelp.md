# ❔ Kontextová nápověda pro web

V rámci řešení HelpViewer je k dispozici [plugin][PluginR] pro prohlížeče s jádrem Chromium (Chrome, Edge).

## Funkce

Plugin zajišťuje přidání akce ❔ **Co je zde?** do menu pravého tlačítka myši, která následně otevře kapitolu konkrétní kapitoly v konkrétním souboru nápovědy stejným způsobem, jako to bylo v minulosti obvyklé u operačních systémů.

## Instalace

**Systémový administrátor** musí plugin nainstalovat na stanicích uživatelů v **režimu pro vývojáře** (chrome://extensions/). Plugin není v Chrome Web Store.

## Propojení aplikace a nápovědy

**Napojení nápovědy v aplikaci zajistí programátor**.  
Stačí definovat **objekt hvHelpFile** ve webové aplikaci:

```javascript
var hvHelpFile = {
  file: 'hlp-user/Help-__.zip',
  viewer: 'https://helpviewer.github.io/index.html',
  //viewer: '$/index.html', // relativní cesta k prohlížeči odvozená z umístění aplikace
  routing: false
  //, extension: '.md'
  //, offset: 0
}
```

Definici lze měnit dynamicky podle kontextu (např. podle stránky). Více detailů v [dokumentaci pluginu][PluginR].

## Získání seznamu kapitol

Pro autory nápovědy jsou klíčové názvy kapitol, odvozené z atributu **id** ovládacích prvků v aplikaci.  
**Programátor je musí poskytnout** – odpovídá za konfiguraci pluginu.

### Kroky pro programátora

1. Otevřete konzoli pro vývojáře (F12) na stránce aplikace.
2. Získejte všechna ID prvků:

```javascript
allElements = Array.from(document.body.querySelectorAll('*')).map(x => x.id).filter(x => x);
```

3. Pro sloučené ID (např. stromy, seznamy - sloučí se jen předpony před **|**):

```javascript
allElements = [...new Set(Array.from(document.body.querySelectorAll('*')).map(x => x.id).filter(x => x).map(x => x.split('|')[0]))];
```

4. **Ověřte chování** na cílovém prostředí - parametry **routing, extension a offset** ovlivňují finální jméno kapitoly.

## Speciální případy

- Pro **prvky bez ID** se otevírá kapitola **noid.md** (nebo noid.(extension) z konfigurace)
- Testujte na různých stránkách/formulářích podle architektury aplikace

## Ladění a tipy

1. Pokud položka ❔ chybí, zkontrolujte **hvHelpFile** v konzoli: console.log(hvHelpFile).
2. Jméno otevřené kapitoly je chybné nebo se nezobrazuje žádný text kapitoly? Ověřte ID prvku pod kurzorem a konfiguraci offset/routing/extension. Ověřte také zda jste soubor kapitoly v nápovědě založili.
3. Použijte **\$/index.html** pro samostatné nasazení s aplikací - **\$** zde znamená relativní cesta vzhledem k současné URI aplikace (záložky ze které se spustil příkaz ❔).
4. Bezpečnost: Plugin běží v izolovaném kontextu a neovlivňuje aplikaci.

[PluginR]: ?d=https://raw.githubusercontent.com/HelpViewer/PluginChromeHelpViewer/master/ "PluginChromeHelpViewer"
