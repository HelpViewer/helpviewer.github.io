# Dokumentace pro autory

Cílem dokumentace je popsat: 
- Postupy pro tvorbu vlastní nápovědy,
- Vnitřní formát indexací a metadat,
- Významná specifika HelpViewer a jeho procesů,
- Přístupy pro integraci mezi aplikacemi a nápovědou
