# Dokumentace pro autory

Cílem dokumentace je popsat: 
- Postupy pro tvorbu vlastní nápovědy,
- Vnitřní formát indexací a metadat,
- Významná specifika HelpViewer a jeho procesů,
- Přístupy pro integraci mezi aplikacemi a nápovědou
- Přehled struktury GitHub organizace HelpViewer a popis verzování
- Popis možností rozšíření samotného projektu
