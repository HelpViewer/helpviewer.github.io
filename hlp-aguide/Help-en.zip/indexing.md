# 🔎 Chapter indexation

Just after the chapter creation there can be suitable to introduce new chapter to some of these lists:

- 📖 TOC tree (tree.lst)
- 📑 File list (files.lst)
- 📇 Keywords dictionary (keywords.lst)
- 📇 Keyword - file relation (keywords-files.lst)

In tree subchapter there are described internal data structures of these files.
