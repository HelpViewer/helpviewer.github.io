# ❔ Contextual help for the web

The HelpViewer solution includes a [plugin][PluginR] for browsers based on the Chromium engine (Chrome, Edge).

## Features

The plugin adds the ❔ **What's here?** action to the right-click menu, which then opens a specific chapter in a specific help file in the same way that was common in operating systems in the past.

## Installation

**The system administrator** must install the plugin on user workstations in **developer mode** (chrome://extensions/). The plugin is not available in the Chrome Web Store.

## Integrating the application and help

**The programmer is responsible for integrating the help into the application**.  
Simply define the **hvHelpFile object** in the web application:

```javascript
var hvHelpFile = {
  file: 'hlp-user/Help-__.zip',
  viewer: 'https://helpviewer.github.io/index.html',
  //viewer: '$/index.html', // relative path to the viewer derived from the application location
  routing: false
  //, extension: '.md'
  //, offset: 0
}
```

The definition can be changed dynamically based on context (e.g., by page). More details in the [plugin documentation][PluginR].

## Retrieving the list of chapters

For help authors, chapter names - derived from the **id** attribute of controls in the application - are key.  
**The programmer must provide them** - they are responsible for configuring the plugin.

### Steps for the programmer

1. Open the developer console (F12) on the application page.
2. Retrieve all element IDs:

```javascript
allElements = Array.from(document.body.querySelectorAll('*')).map(x => x.id).filter(x => x);
```

3. For combined IDs (e.g., trees, lists - only prefixes before **|** are combined):

```javascript
allElements = [...new Set(Array.from(document.body.querySelectorAll('*')).map(x => x.id).filter(x => x).map(x => x.split('|')[0]))];
```

4. **Verify behavior** in the target environment - the **routing, extension, and offset** parameters affect the final chapter name.

## Special cases

- For **elements without an ID**, the **noid.md** chapter opens (or noid.(extension) from the configuration)
- Test on different pages/forms according to the application architecture

## Debugging and tips

1. If the ❔ item is missing, check **hvHelpFile** in the console: console.log(hvHelpFile).
2. Is the name of the opened chapter incorrect, or is no chapter text displayed? Verify the element ID under the cursor and the offset/routing/extension configuration. Also verify that you have created the chapter file in the help.
3. Use **\$/index.html** for standalone deployment with the application - **\$** here denotes a relative path relative to the current application URI (the tab from which the ❔ command was launched).
4. Security: The plugin runs in an isolated context and does not affect the application.

[PluginR]: ?d=https://raw.githubusercontent.com/HelpViewer/PluginChromeHelpViewer/master/ "PluginChromeHelpViewer"
