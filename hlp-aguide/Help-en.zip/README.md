# Authoring Guide

The main goal is to describe: 
- How to create your own help file,
- Internal indexes and metadata structures,
- Notable HelpViewer and its processes specifics,
- Integration scenarios between your application and help file
- HelpViewer GitHub overview and versioning description,
- How to extend HelpViewer itself
