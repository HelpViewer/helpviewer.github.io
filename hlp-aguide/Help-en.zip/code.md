# 🧾 Code listing

There is no support for this in HTML documents.

You will insert code listing to **md** file this way:

````markdown
```javascript
  function configGetValue(key, backup, CFG = FILE_CONFIG) {
  //...
  } 
```
````

Example:

```javascript
  function configGetValue(key, backup, CFG = FILE_CONFIG) {
  //...
  } 
```

- For more examples read the [Prism][Prism] library documentation. 

[Prism]: https://prismjs.com/ "Prism - syntax highlighting"
