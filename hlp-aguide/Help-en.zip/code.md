# 🧾 Code listing

There is no support for this in HTML documents.

You will insert code listing to **md** file this way:

````
```
Your code snippet text
```
````

Example:

```
Your code snippet text
```
