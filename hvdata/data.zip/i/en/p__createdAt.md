⚙️ Filled automatically by logic.

Date and time of event object creation.
