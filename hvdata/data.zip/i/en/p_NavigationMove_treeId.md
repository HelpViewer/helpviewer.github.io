ID of tree component (ul component id) interconnected with plugin configuration. E.g.: tree
