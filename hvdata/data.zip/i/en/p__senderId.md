Sending plugin id (plugin which provided conversion of javascript event to eventbus event).
