Mapping file raw plain text data. Mapping integer indexes.
