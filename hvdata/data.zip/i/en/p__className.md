Javascript class name.
