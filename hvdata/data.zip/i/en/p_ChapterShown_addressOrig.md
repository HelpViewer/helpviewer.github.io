URI address (original value from **ShowChapter** event).
