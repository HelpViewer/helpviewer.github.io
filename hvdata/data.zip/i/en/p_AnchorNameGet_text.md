Anchor heading text.
