WCAG role name. E.g.: navigation
