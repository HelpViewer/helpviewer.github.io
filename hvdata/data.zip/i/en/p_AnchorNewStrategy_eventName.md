Strategy name for creating anchor names.
