Accepted event object from system.
