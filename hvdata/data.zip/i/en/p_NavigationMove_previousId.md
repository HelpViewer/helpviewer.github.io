Previous id of tree item relative to last move opened item. E.g.: 2
