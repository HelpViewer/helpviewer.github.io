Plugin instance name in form (class):(instance) . If instance is not populated, then string ends with :.
