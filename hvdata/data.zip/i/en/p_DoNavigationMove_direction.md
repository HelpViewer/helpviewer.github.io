Navigation movement direction.

Values:

| Value | Button | Meaning |
|---|---|---|
| -1 | ⬅ | Move one step/item left |
| 0 | ⬆ | Move level up |
| 1 | ➡ | Move one step/item right |
