Anchor heading level. Possible values 1..6 (as h1 to h6).
