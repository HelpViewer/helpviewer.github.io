DOM in memory (virtual, not connected) document.
