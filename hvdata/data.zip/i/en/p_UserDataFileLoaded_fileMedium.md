**(string(UserDataFileLoadedFileType))**

File medium resolved from help (data) file (URI: **d** GET parameter).

| Value | Meaning |
|---|---|
| LOCALDIR | Local directory is used |
| LOCALARC | Local ZIP file is used |
| INPUTFIELD | Input field from loading form data are used (CORS active case fallback alternative) |
| NETWORK | Network resource / URI path is used |
