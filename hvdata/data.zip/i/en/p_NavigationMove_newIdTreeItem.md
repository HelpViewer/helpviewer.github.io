Current (after move) complete id of opened tree item. E.g.: tree|3
