The complete identifier of the element that should be changed.
