Alias name of module which holds target tree component which should accept new data.
