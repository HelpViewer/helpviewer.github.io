Link to standard javascript event object (usually PointerEvent).
