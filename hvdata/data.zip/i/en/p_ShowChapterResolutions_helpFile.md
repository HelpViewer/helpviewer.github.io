Help file URI path. **d** GET parameter value.
