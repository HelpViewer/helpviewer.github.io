Configuration option ⚙️ EVENTBUSEVENTID override for given event.
