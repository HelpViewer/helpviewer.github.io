Event name of operation which failed. Scope: defined events in **pPluginOperationFailed** .
