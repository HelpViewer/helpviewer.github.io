HTML (or) content for cursor. This text/image/unicode icon will follow cursor mouse move.
