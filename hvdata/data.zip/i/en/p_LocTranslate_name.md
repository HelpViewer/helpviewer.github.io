Translation key name.
