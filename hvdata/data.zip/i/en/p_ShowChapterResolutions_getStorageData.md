**(FUNCTION)**

Getter function for data from storage (general shorthand). **pTRTriage** plugin setting this from these sources:

- STO_HELP (default; help file storage)
- getAppData - STO_DATA (application resources)
- STORAGE_NETW - network URI request (Git repositories or other URI addresses)
