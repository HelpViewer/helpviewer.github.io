Language strings with dynamic information inside.
