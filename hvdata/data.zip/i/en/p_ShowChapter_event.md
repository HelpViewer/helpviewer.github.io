Link to standard JS event object (usually PointerEvent).
