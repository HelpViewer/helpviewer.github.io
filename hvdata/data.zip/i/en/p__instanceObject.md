Plugin object instance.
