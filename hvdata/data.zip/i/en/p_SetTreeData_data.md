Tree plaintext data. [Structure description][SDesc]

[SDesc]: https://helpviewer.github.io/?p=mdata%2Ftree.lst.md&d=hlp-aguide/Help-__.zip "Structure description (Authoring Guide)"
