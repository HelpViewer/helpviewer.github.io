⚙️ Filled automatically by event bus.

Last processing handler name (plugin::method name).
