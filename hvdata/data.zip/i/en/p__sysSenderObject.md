Reference to javascript object which has attached an event listener on itself.
