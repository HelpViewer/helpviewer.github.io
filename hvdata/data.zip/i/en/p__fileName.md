Relative path and file name.
