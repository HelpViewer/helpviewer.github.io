⚙️ Filled automatically by event bus.

Processing handler name (plugin::method name) which set **stop** signal to **true** and thus stopped rest of next processing of event.
