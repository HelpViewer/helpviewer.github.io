Identifier root (group) of the element that was clicked. Right part after 1st | or - in element.id
