General shorthand for DOM document object. Starts with in memory document (**pTRFlushToMemDOM**). Later then in render process there is switched to visual (standard) document (**pTRFlushToDOM**).

Default value is visual (standard) document (selected as 1st value in **pTopicRenderer**).
