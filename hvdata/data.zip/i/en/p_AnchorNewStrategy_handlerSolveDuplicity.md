Handler for solving duplicities in anchor names (usually 2 headings with the same text can lead to duplicates).
