Internal state of heading anchors processing. Used by 🖼️ [pTRAnchorName][pTRAnchorName] plugin.

[pTRAnchorName]: :_plg:pTRAnchorName.md "pTRAnchorName"
