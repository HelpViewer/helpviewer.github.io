Flag to stop processing further stages of chapter rendering. Extended form of **stop** property.
