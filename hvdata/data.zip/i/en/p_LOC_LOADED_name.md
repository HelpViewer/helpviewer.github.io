Translation language name.
