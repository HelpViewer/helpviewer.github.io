Local storage key new value.
