DOM visual (standard, connected) document.
