New heading string which should be set to top heading panel.
