URI address (translated by triage phase plugins).
