Handler function for click event.
