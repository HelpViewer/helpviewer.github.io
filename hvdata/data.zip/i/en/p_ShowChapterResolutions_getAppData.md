**(FUNCTION)**

Getter function for **STO_DATA** (application resources) storage.
