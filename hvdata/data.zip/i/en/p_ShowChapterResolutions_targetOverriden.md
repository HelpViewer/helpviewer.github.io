Information if standard target container has been overriden (true) or not (false).
