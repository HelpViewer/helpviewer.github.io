stop signal. If you will set this value to **true**, then next event handlers in chain registered in EventBus will be skipped and next processing of event is stopped.
