Handler - event callback for event data which is started just after event handler finished. Passed externally from site of call.
