**(string)**

Chapter text content. 1st stages can be markdown or other format (even HTML), later stages HTML source code is present here.
