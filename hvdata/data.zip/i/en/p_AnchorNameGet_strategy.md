Exact strategy name to be used. Must by defined in static handlersGetOne in 🖼️ [pTRAnchorName][pTRAnchorName] or created by ⚡ [AnchorNewStrategy][AnchorNewStrategy] event. Skip this definition if you do not want to override the ⚙️ **STRATEGY** configuration option, which is used here as the default.

[AnchorNewStrategy]: :_evt:AnchorNewStrategy.md "AnchorNewStrategy"
[pTRAnchorName]: :_plg:pTRAnchorName.md "pTRAnchorName"
