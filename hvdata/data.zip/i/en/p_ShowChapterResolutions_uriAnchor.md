**(string)**

Uri of anchor inside chapter file if requested.
