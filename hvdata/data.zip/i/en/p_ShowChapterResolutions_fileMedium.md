**(string)**

File medium resolved from **uri** parameter.
