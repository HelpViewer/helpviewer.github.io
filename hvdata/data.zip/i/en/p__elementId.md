The complete identifier of the element that was clicked.
