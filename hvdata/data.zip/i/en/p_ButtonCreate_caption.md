Caption of button UI element. It can be a string or any Unicode icon (letter).
