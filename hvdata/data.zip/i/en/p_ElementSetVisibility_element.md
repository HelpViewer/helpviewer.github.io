**(output value)**

Link to changed DOM object.

**result** contains new visibility value here for given object (**elementId**).
