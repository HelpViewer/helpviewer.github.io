✍️ Filled manually.

⚙️ Forwarded automatically by next logic.

⇒ Result value from event processing. 

Handlers are providing this value. Next internal logic is forwarding and extracting the value as flat function return value.
