Backup value if config key is not defined or holds falsy value.
