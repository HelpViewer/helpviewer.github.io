Config file key name.
