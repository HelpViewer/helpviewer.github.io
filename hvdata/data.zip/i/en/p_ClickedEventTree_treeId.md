ID of target tree component (ul component id) which has been clicked.
