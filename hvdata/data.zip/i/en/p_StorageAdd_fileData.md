Raw data for newly appended storage. Effective if you have byte array already loaded.
