Output value format.

Usual values:

- STOF_TEXT (text) (default)
- STOF_B64 (base64)
