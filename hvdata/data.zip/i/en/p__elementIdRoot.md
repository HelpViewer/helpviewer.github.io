Identifier root (group) of the element that was clicked. Left part to 1st | or - in element.id
