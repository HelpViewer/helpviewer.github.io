Chapter index plain text data.
