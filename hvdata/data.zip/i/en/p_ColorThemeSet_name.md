**(undefined | string)**

Name of required color theme.

Use:

- **undefined** for select next one in sequence (defined internally)
- **exact name** for activate exact color theme
