⚙️ Filled automatically by logic.

Name of current event. Each event object class can be reused with multiple eventName values as e.g. IEvent class.
