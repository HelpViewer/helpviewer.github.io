Heading of chapter for top panel.
