Desired id of new tree object.
