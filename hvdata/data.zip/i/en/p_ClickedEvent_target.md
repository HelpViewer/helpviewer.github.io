Link to clicked DOM object on page
