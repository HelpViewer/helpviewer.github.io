Handler function for button click event.
