New strategy name.
