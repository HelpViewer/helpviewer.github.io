Shorthand function to call event.preventDefault() function for standard javascript event if passed to wrapped event.
