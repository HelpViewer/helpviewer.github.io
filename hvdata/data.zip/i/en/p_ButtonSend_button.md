**(input field - button)**

Processed button object which should be attached to some toolbar.
