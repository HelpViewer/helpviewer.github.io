List of string keys and constants which should pass to translation as dynamic information data. 

E.g.: There are 7 new messages. ... {count : 7} can be passed here. For more examples see zip/lang/en/lstr.js file. These values will be usually used here in this context.
