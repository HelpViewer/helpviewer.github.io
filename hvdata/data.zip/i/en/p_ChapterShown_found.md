Flag if given chapter file has been found in help or data file. If not, then **false** is returned here.
