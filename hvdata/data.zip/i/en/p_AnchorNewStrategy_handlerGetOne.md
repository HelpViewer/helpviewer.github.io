Handler for get a single anchor name in strategy.
