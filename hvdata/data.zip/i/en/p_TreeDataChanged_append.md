Data in target tree should be append to end (**true**) or overwritten (**false**).
