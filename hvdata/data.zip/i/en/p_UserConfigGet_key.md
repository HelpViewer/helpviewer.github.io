Local storage key name.
