Storage name.

Usual values:

- STO_DATA
- STO_HELP
