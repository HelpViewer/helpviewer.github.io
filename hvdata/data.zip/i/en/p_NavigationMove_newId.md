Current (after move) id of opened tree item. E.g.: 3
