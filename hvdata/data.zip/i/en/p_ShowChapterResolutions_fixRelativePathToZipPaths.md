Helper function for fix paths in chapter hyperlinks and resources to relative paths in ZIP data file.
