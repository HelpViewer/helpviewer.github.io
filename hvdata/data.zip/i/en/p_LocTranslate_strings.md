Object with key and values which are forwarded to translation function. 

Usually empty (keep default) but in certain situations you possible need to forward some data to translation function to provide correct output. 

E.g.: There are **7** new messages. ... {count : 7} will be passed here. For more examples see **zip/lang/en/lstr.js** file. These values will be usually used here in this context.

zip/lang/en/lstr.txt file is planned to be used for plain static values without this extension.
