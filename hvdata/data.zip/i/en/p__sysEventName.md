Standard javascript event name (beforeprint, popstate, fullscreenchange, keydown, ...).
