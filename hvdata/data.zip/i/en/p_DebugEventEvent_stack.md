Stacktrace dump
