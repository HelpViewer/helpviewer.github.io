**(HTMLElement (a))**

Reference to clicked a href hyperlink which has been clicked and created this event.
