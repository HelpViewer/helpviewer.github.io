Setter for document title and title in top panel from input data (usually from **heading** property in the same object).
