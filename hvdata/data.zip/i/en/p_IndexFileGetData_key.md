Partial keyword or phrase for search in dictionary. Searched from the middle of the word.
