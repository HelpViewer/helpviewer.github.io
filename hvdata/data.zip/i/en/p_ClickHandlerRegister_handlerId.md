String id of handler. The similar information to [ClickedEvent.elementIdRoot][ClickedEvent-elementIdRoot]

[ClickedEvent-elementIdRoot]: ?p=:_evtD:pClickConverter::ClickedEvent.md "ClickedEvent.elementIdRoot"
