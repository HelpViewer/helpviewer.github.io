New content of watermark.

- Direct text means text content.
- Function () => 'path/to/file.png' means file path to image to be used. Cannot be inside ZIP file, must be on disk.
