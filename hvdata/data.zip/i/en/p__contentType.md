**(ChapterContentType (string) | undefined)**

Chapter content type specification.

| ChapterContentType | Meaning |
|---|---|
| CHAPTER_SOURCE | Source text of chapter |
| KEYWORD_LIST | Listing of specific keyword |
| INTERNAL_RESOURCE | Internal application resource |
| NETWORK_RESOURCE | Resource from network |
