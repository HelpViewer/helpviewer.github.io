Error object instance (or error message text).
