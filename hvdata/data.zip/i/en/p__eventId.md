⚙️ Filled automatically by logic.

Event id (similar role to correlation id).
