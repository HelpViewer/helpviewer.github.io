Page (div) element id. sp- prefix is added in time of processing.
