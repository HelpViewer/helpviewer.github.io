pTopicRenderer token. Loading of data (**pTRLoadData:-load** plugin is skipped as the data has been passed externally to given request)
