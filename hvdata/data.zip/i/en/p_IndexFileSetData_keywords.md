Keyword list file raw plain text data. Keyword texts
