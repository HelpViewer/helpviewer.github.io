New visibility value.
