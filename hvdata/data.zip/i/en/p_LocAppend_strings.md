Language strings with static string only.
