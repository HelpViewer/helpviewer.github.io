Handler for prepare internal data object for strategy.
