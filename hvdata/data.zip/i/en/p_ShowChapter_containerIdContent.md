HTMLElement id for content pane (div). Pass **undefined** if you want to use configuration option **IDCONTENT** value. Usual value: **content**.
