Maximum numbers of keywords which should be shown in search listing.

Priority of population:

1. Externally passed count in event object
2. Local storage key **keywordListingCount**
3. Constant amount: **50**

**undefined** equals to not any limit -> show all.
