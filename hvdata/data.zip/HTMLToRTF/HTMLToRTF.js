/**
 * HTML -> RTF converter (MS Word 97 compatible)
 * Used reference: https://www.biblioscape.com/rtf15_spec.htm , https://latex2rtf.sourceforge.net/RTF-Spec-1.5.pdf
 */

function rowsToArray(t) {
  if (!t) return [];
  return t.replace(/\r\n|\r/g, '\n').split('\n');
}

function HTMLToRTF(parent, header, activeLanguage, config, ctx, document, author) {
  function clearHash(text) {
    let cleanedText = text;
    if (text.endsWith('#'))
      cleanedText = text.substring(0, text.length - 1);
    return encodeToUTF(cleanedText.trim());
  }

  const handlerBold = (node, ctx, children) => `{\\b ${encodeToUTF(children)}\\b0}`;

  function getLabel(node) {
    const found = [... node?.childNodes].filter(x => x.getAttribute)
      .map(x => x.getAttribute('href')?.substring(1).replace(/[-.]/g, '_') || x.id).filter(x => x)
      .map(x => `{\\*\\bkmkstart sec_${x}}{\\*\\bkmkend sec_${x}}`).join('') || '';
    return found;
  }

  function escapeRTF(text) {
    if (!text) return '';
    return text
      .replace(/\\/g, '\\\\')
      .replace(/{/g, '\\{')
      .replace(/}/g, '\\}')
      .replace(/\r\n|\r|\n/g, '\\par ');
  }

  const handlers = {
    ul: (node, ctx, children) => {
      ctx.listStack.push('itemize');
      const body = children;
      ctx.listStack.pop();
      return body;
    },

    ol: (node, ctx, children) => {
      ctx.listStack.push('enumerate');
      const body = children;
      ctx.listStack.pop();
      return body;
    },

    li: (node, ctx, children) => {
      const level = ctx.listStack ? ctx.listStack.length : 1;
      const indentTwips = 720 * level; // 720 twips = 0.5 inch cca. 12pt
      const isEnum = (ctx.listStack && ctx.listStack[ctx.listStack.length - 1] === 'enumerate');
      if (isEnum) {
        // simplified - no counter
        return `{\\pard\\li${indentTwips} ${escapeRTF('1.')}\\tab ${children}\\par}\n`;
      } else {
        // bullet
        return `{\\pard\\li${indentTwips} \\bullet\\tab ${children}\\par}\n`;
      }
    },

    img: (node, ctx, children) => {
      ctx.i_img = (ctx.i_img || 0) + 1;
      const embed = ctx.embeds.get ? ctx.embeds.get(node.src) : null;
      let pict = '';

      function base64ToHex(base64) {
        if (typeof base64 !== 'string') return '';
      
        base64 = base64.replace(/\s+/g, '').replace(/-/g, '+').replace(/_/g, '/');
        const pad = base64.length % 4;
        if (pad) base64 += '='.repeat(4 - pad);
      
        try {
          const raw = atob(base64);
          const bytes = Uint8Array.from(raw, c => c.charCodeAt(0));
          return Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('');
        } catch (e) {
          return '';
        }
      }

      if (embed) {
        let format = 'png';
        let hex = '';
        if (typeof embed === 'object') {
          format = embed.format || 'png';
          if (embed.data && embed.data.startsWith('data:')) {
            const matches = embed.data.match(/base64,(.*)$/);
            if (matches) hex = base64ToHex(matches[1]);
          } else if (embed.data && /^[0-9a-fA-F]+$/.test(embed.data)) {
            hex = embed.data;
          } else if (embed.data) {
            hex = base64ToHex(embed.data);
          }
        } else if (typeof embed === 'string' && embed.startsWith('data:')) {
          const m = embed.match(/base64,(.*)$/);
          if (m) hex = base64ToHex(m[1]);
          // try infer format
          if (embed.indexOf('image/jpeg') >= 0) format = 'jpeg';
          else if (embed.indexOf('image/png') >= 0) format = 'png';
        }

        let control = '\\pngblip';
        if (format === 'jpeg' || format === 'jpg') control = '\\jpegblip';
        else if (format === 'wmf' || format === 'emf') control = '\\wmetafile8';

        if (hex) {
          pict = `{\\pard\\qc{\\pict${control}\n${hex}}\\par}\n`;
        } else {
          // fallback: not any data
          pict = `{\\pard\\qc [Image ${ctx.i_img} - not embedded] \\par}\n`;
        }
      } else {
        pict = `{\\pard\\qc [Image ${ctx.i_img} - missing] \\par}\n`;
      }

      const caption = node.getAttribute('title') || '';
      const cap = caption ? `{\\pard\\qc \\i ${escapeRTF(caption)}\\i0 \\par}\n` : '';
      return pict + cap;
    },

    svg: (node, ctx, children) => {
      // RTF not support SVG!
      // TODO: convert SVG to PNG via canvas and embed as image?
      ctx.i_svg = (ctx.i_svg || 0) + 1;
      //const embed = ctx.embeds.get ? ctx.embeds.get(node) : null;
      // Reuse img handler logic via fake node
      return handlers.img(node, ctx, children);
    },

    h1: (node, ctx, children) => `{\\pard{\\s1 ${clearHash(children)}${getLabel(node)}\\par}\n`,
    h2: (node, ctx, children) => `{\\pard{\\s2 ${clearHash(children)}${getLabel(node)}\\par}\n`,
    h3: (node, ctx, children) => `{\\pard{\\s3 ${clearHash(children)}${getLabel(node)}\\par}\n`,
    h4: (node, ctx, children) => `{\\pard{\\s4 ${clearHash(children)}${getLabel(node)}\\par}\n`,
    h5: (node, ctx, children) => `{\\pard{\\s5 ${clearHash(children)}${getLabel(node)}\\par}\n`,
    h6: (node, ctx, children) => `{\\pard{\\s6 ${clearHash(children)}${getLabel(node)}\\par}\n`,

    p: (node, ctx, children) => `{\\pard ${children}\\par}\n`,

    div: (node, ctx, children) => {
      if (node.classList && (node.classList.contains('toolbar-item') || node.classList.contains('toolbar')))
        return '';

      if (node.classList && node.classList.contains('page-break'))
        return '\\page\n';

      return children;
    },

    code: (node, ctx, children) => {
      // No language -> monospace
      const codeText = node.textContent || '';
      const escaped = escapeRTF(codeText);
      return `{\\pard\\f1\\fs20 ${escaped}\\par}\n`;
    },

    strong: handlerBold,
    b: handlerBold,
    em: (node, ctx, children) => `{\\i ${children}\\i0}`,

    table: (node, ctx, children) => {
      return `${children}\n`;
    },

    thead: (node, ctx, children) => {
      const cols = rowsToArray(children.trim());
      const boldCols = cols.map(c => `{\\b ${escapeRTF(c).replace(/\\\\par/g, '\\tab')}\\b0}`).join('\\tab ').replace(/ \\tab \\tab/g, '').replace(/\\tab/g, '\\tab \\tab');
      return `${boldCols} \\par\n`;
    },

    td: (node, ctx, children) => {
      return `${children}\\tab `;
    },

    tr: (node, ctx, children) => {
      if (node.parentElement && node.parentElement.tagName && node.parentElement.tagName.toLowerCase() === 'thead')
        return children;

      const tds = Array.from(node.children).filter(child => {
        const t = child.tagName && child.tagName.toLowerCase();
        return t === 'td' || t === 'th';
      });

      if (tds.length === 0) {
        return `${children}\\par\n`;
      }

      const colTexts = tds.map(td => walk(td, ctx));
      return colTexts.join('') + '\\par\n';
    },

    a: (node, ctx, children) => {
      if (children.trim().replace('\\#', '#').length == 1)
        return '';

      let href = node.getAttribute('id') || '';
      if (href && node.parentElement.tagName.toLowerCase().substring(0, 1) == 'h')
        return;

      // local text hyperlink
      href = node.getAttribute('href') || '';
      href = decodeURI(href || '');

      if (href.startsWith('http')) {
        // external link (http)
        // RTF: {\field{\*\fldinst HYPERLINK "url"}{\fldrslt display}}
        return `{\\field{\\*\\fldinst HYPERLINK "${href}"}{\\fldrslt ${encodeToUTF(children)}}}`;
      }

      const rawHref = node.getAttribute('href')?.replace(/[-.]/g, '_') || '';
      if (rawHref.startsWith('#')) {
        const name = rawHref.substring(1);
        // link to bookmark (chapter)
        return `{\\field{\\*\\fldinst HYPERLINK \\\\l "sec_${name.replace(/[-.]/g, '_')}"}{\\fldrslt ${encodeToUTF(children)}}}`;
      } else {
        try {
          const absolute = node.href ? decodeURI(node.href) : href;
          if (!absolute)
            return;
          return `{\\field{\\*\\fldinst HYPERLINK "${absolute}"}{\\fldrslt ${encodeToUTF(children)}}}`;
        } catch (e) {
          return children;
        }
      }
    },

    script: (node, ctx, children) => '',
    style: (node, ctx, children) => '',
    br: (node, ctx, children) => `\\line ${children}`,
    summary: (node, ctx, children) => `${children}\\par`,

    default: (node, ctx, children) => encodeToUTF(children)
  };

  // function encodeToUTF(text) {
  //   const bytes = encoder.encode(text);
  //   let rtfText = Array.from(bytes)
  //     .map(b => `\\\\'${b.toString(16).padStart(2,'0')}`).join('');
  //   return rtfText;
  // }

  function encodeToUTF(rtfText) {
    // let rtfText = '';
    // for (let i = 0; i < text.length; i++) {
    //   const cp = text.codePointAt(i);
    //   let uCode = cp;
    //   if (cp > 0xFFFF) {
    //     uCode = 0x110000 - cp;
    //   }
    //   rtfText += `\\u${-uCode}?`;
    //   if (cp > 0xFFFF) i++;
    // }
    return rtfText;
  }

  function walk(node, ctx) {
    if (node.nodeType === Node.TEXT_NODE) 
      return escapeRTF(node.textContent);
    const children = Array.from(node.childNodes)
      .map(child => walk(child, ctx))
      .join('');
    const tag = node.nodeName.toLowerCase();
    const handler = handlers[tag] || handlers.default;
    return handler(node, ctx, children);
  }

  document = document.replace(/_AUTH_/g, author);
  document = document.replace(/_DOCNAME_/g, header);
  document = document.replace(/_LANG_/g, config[activeLanguage] || activeLanguage);

  let rtfBody = walk(parent, ctx);
  rtfBody = rtfBody.replace(/\\par\s*\{\s*\\pard{\\s/g, '\\pard{\\s');
  rtfBody = rtfBody.replace(/ {\\pard \\par}/g, '');
  rtfBody = rtfBody.replace(/{\\pard{\\s/, '\\pard{\\s');

  return [document, rtfBody];
}
