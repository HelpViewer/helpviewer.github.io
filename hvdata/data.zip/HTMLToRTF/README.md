# HTMLToRTF

HTML to RTF (Word 97) conversion tool.

## Features

- One javascript file
- Capable to run from your local disk
- No modules or any backend/framework needed
- around 10 kB (not minified)
- Template can be customized
- Part of bigger [project][HV] that has been refactored to be independent

## Demo

1. [Demo implementation][Demo] is a single HTML file to show you needed configuration to make it work.

    1. Scroll down and click **Convert to RTF** button
    2. Result will be shown in textarea under the button
    3. **Copy** button doesn't have any function and it is kept exactly as it is being produced by Prism library (manually copied here to demonstrate how does this case works)

2. **HelpViewer integration** source code: [export handler][HVINT] and [pre export preparation for image links collection][HVINT2]. This code is executed when you will click on top right dropdown button (📥) and select **RTF** format.

## Installation

Add reference to head section:
```html
<script src="https://raw.githubusercontent.com/HelpViewer/HTMLToRTF/refs/heads/main/HTMLToRTF.js" type="text/javascript"></script>
```

or copy this file to your local environment.

## API

Call **HTMLToRTF** function with  
parameters:
- parent - HTMLElement which contains all your HTML data which should be converted to RTF
- header - String which is used as document name (used on title page and in page headings)
- activeLanguage - language of your document (use en for default)
- config - Configuration values (object with key value string pairs)
- ctx - internal state context for single run (provide: { listStack: [], i_img: 0, i_svg: 0, embeds: new Map() } as default)
  - listStack - ul/ol nesting sequence
  - i_img - img tags found counter
  - i_svg - svg tags found counter
  - embeds - previously collected embedded objects (img, svg)
- document - base RTF document template (you need to create your own, no default here, consult demo)
- author - document author name

to get result : array of :
- 0 - base template
- 1 - your HTML DOM converted to RTF

which must be processed like this:

```javascript
result[0].replace('%DOC%', result[1]);
```

to get complete RTF source code.

## Known limits and issues

- Headings are correctly defined but without any special format (you can easily change style template in Word afterwards)
- Output from [Prism][Prism] is printed in "typewriter" font (no colors and format)
- Output from [Marked][Marked] is skipped
- Uses default ANSI codepage (East Europe and other languages exports may have malformed letters with diacritics)
- Images are not imported
- Tables are imported via texts with **tab** spaces
- Unicode characters are malformed, but inserted
- Tool only generates **RTF** source code for Word 97 and higher
- Tool focuses on using only the basic constructs of RTF 1.5
- Text formatting functions are used only to a basic extent (despite your HTML can be more rich in format)

## Tips

### Page break

Provide **DIV** with CSS class **page-break**:

```html
<div class="page-break"></div>
```

to spots where you would like to emit page break in RTF.

Provide exactly what is shown in the example here, without any content inside, because the content here is skipped during the conversion process.


## Version publishing

- No managed packages or artifacts are planned to be released from this repository
- Work directly with the content of the main branch of the GitHub repository
- Repository is used with Git submodules in **HelpViewer** project

[Marked]: https://marked.js.org/ "Marked JavaScript library - md files to HTML renderer"
[Prism]: https://prismjs.com/ "Prism - syntax highlighting"
[HV]: https://github.com/HelpViewer/HelpViewer "HelpViewer"
[Demo]: https://github.com/HelpViewer/HTMLToRTF/blob/main/.extras/index.html "Demo"
[HVINT]: https://github.com/HelpViewer/HelpViewer/blob/master/zip/plugins/pExportRTF.js "Export handler"
[HVINT2]: https://github.com/HelpViewer/HelpViewer/blob/master/zip/plugins/puiButtonExport.js#L41 "Export : image links collection"
