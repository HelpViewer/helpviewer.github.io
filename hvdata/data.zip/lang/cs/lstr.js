var _lstr = {
  'MSG_NODATA' : (s) => `Nebyl určen soubor nápovědy - zadejte parametr <b>?${PAR_NAME_DOC}=</b> do adresního řádku. Byl použit výchozí název <b>${dataPath}</b>. Pokud je panel prohlížení prázdný, pak soubor <b>${dataPath}</b> pravděpodobně neexistuje v místním adresáři prohlížeče. V dalším kroku zkuste zkontrolovat parametr <b>${PAR_NAME_PAGE}=</b>, abyste ověřili, zda ukazuje na soubor, který se v souboru nápovědy skutečně nachází.`,
  'MSG_PATH_NOT_FOUND_IN_ARCH' : (s) => `Zadaná cesta <b>${pagePath}</b> se v souboru nápovědy <b>${dataPath}</b> nenachází.`,
};