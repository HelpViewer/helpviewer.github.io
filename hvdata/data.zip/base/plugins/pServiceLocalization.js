class pServiceLocalization extends pServicePlugin {
  init() {
    super.init();

    const TI = this;
    TI.catalogizeEventCall(TI._pluginActivated, EventNames.LocAppend);
  }

  _pluginActivated(pluginName, instanceName, instance, storageName) {
    const langFileJS = 'lstr.js';
    const langFileTXT = 'lstr.txt';
    const lang = this.lang
    const baseDir = storageName == STO_DATA ? `${pluginName}/${lang}` : `../${lang}/${pluginName}`;
    
    Promise.all([
      storageSearch(storageName, `${baseDir}/${langFileTXT}`),
      storageSearch(storageName, `${baseDir}/${langFileJS}`),
      storageSearch(storageName, `${pluginName}/${langFileTXT}`),
      storageSearch(storageName, `${pluginName}/${langFileJS}`),
    ]).then(([txt, js, txtInArc, jsInArc]) => {
      if (txtInArc)
        txt = txtInArc;

      if (jsInArc)
        js = jsInArc;

      var dynStrings = undefined;

      if (js) {
        this.addPlugin(pluginName, instanceName);
        const jsAlias = `lngk_${pluginName}`;
        $O(jsAlias)?.remove();
        appendJavaScript(jsAlias, js, document.head);
        dynStrings = _lstr;
      }

      if (txt) {
        this.addPlugin(pluginName, instanceName);
        sendEvent(EventNames.LocAppend, (x) => {
          x.strings = txt;
          x.dynStrings = dynStrings;
        });
      }
    });
  }

  onETLOC_LOADED(evt) {
    this.lang = evt.name;
    this._doForAllInstances(this._pluginActivated.bind(this));
  }

  onETUserDataFileLoaded(evt) {
    this._doForAllInstances(this._pluginActivated.bind(this));
  }
}

Plugins.catalogize(pServiceLocalization);
