class pTR1stHeadingToTopPanel extends pTRPhasePlugin {
  init() {
    super.init();

    const TI = this;
    
    TI.catalogizeEventCall(TI.onETShowChapterResolutions, EventNames.HeaderSet);
  }

  onETShowChapterResolutions(r) {
    r.result = r.result.then(() => {
      const firstChild = this.doc(r).firstElementChild;
      const firstH1 = $O('h1', r.doc);
    
      if (firstH1 && firstChild === firstH1)
      {
        if (firstH1.innerHTML.startsWith('_')) {
          firstH1.innerHTML = firstH1.innerHTML.trim().substring(1);
          return;
        }
        if (r.setTitle(firstH1.innerHTML.trim())) {
          r.heading = firstH1.innerHTML.trim();
          firstH1.remove();
        }
      }
    });
  }
}

Plugins.catalogize(pTR1stHeadingToTopPanel);
