IEvent.register('BeforePrint', (ebe, syse) => {});
