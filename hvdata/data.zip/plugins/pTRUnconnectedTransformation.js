class pTRUnconnectedTransformation extends pTRPhasePlugin {
  constructor(aliasName, data) {
    super(aliasName, data);
    this.DEFAULT_KEY_CFG_DEFAULTEXTENSION = '.md';
  }

  onETShowChapterResolutions(r) {
    //relative link paths update for ZIP structure
    const checkList = ["href", "src", "data-href"];
    r.result = (r.result || Promise.resolve()).then(() => {
      $A('*', r.doc).forEach((el) => {
        var val;
        checkList.forEach((attr) => {
          if (el.hasAttribute(attr)) {
            val = el.getAttribute(attr);
            if (val 
              && el.tagName.toLowerCase() !== "img"
              && !/^https?:\/\//.test(val) 
              && !val.startsWith("mailto:") 
              && !val.startsWith("tel:") 
              && !val.startsWith("?") 
              && !val.startsWith("#")) {
              
              const newVal = convertRelativePathToViewerURI(val);
              el.setAttribute(attr, newVal);
  
              if (!val.includes('.'))
                val += this.cfgDEFAULTEXTENSION;
              
              if (!val?.startsWith('?d') && !el.getAttribute('data-param'))
                el.setAttribute('data-param', val);    
            }
          }
        });
      });
    });

  }
}

Plugins.catalogize(pTRUnconnectedTransformation);
