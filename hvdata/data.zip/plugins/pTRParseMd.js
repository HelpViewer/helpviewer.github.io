class pTRParseMd extends pTRPhasePlugin {
  static KEY_CFG_FILENAME = 'FILENAME';

  constructor(aliasName, data) {
    super(aliasName, data);
  }

  init() {
    super.init();

    const T = this.constructor;
    this.DEFAULT_KEY_CFG_FILENAME = 'marked.min.js';
    this.cfgFileName = this.config[T.KEY_CFG_FILENAME] || this.DEFAULT_KEY_CFG_FILENAME;
    this.RES_MARKED = new Resource('MARKED', undefined, STO_DATA, this.cfgFileName);
  }

  deInit() {
    this.RES_MARKED?.deInit();
    super.deInit();
  }

  onETShowChapterResolutions(r) {
    if (!window.marked)
      r.result = this.RES_MARKED?.init(r.result);

    r.result = (!r.content || r.content.length == 0) ? r.result : r.result.then(() => r.content = marked.parse(r.content));
  }
}

Plugins.catalogize(pTRParseMd);
