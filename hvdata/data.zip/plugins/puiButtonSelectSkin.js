class puiButtonSelectSkin extends puiButtonSelect {
  constructor(aliasName, data) {
    super(aliasName, data);

    this.DEFAULT_KEY_CFG_ID = 'downP-selSkin';
    this.DEFAULT_KEY_CFG_CAPTION = '🌈';
    this.DEFAULT_KEY_CFG_TARGET = UI_PLUGIN_SIDEBAR;

    this.DEFAULT_KEY_CFG_STOREKEY = 'skin';
    this.DEFAULT_KEY_CFG_DEFAULTSKIN = '';
    this.DEFAULT_KEY_CFG_IDCONTENTCONTAINER = 'content';

    this.dirStyles = 'styles/';
    this.idCSS = 'css-skin';
  }

  async init() {
    super.init();

    const TI = this;
    TI.activeSkin = getUserConfigValue(TI.cfgSTOREKEY) || TI.cfgDEFAULTSKIN;

    var styles = await storageSearch(STO_DATA, `${TI.dirStyles}${FILENAME_DIR_LISTING}`);
    styles = rowsToArray(styles).map(x => x.split('.')[0]);
    styles.unshift('');
    appendComboBoxItems(TI.select, styles, TI.activeSkin);
  }

  deInit() {
    super.deInit();
    $(this.idCSS)?.remove();
  }

  _handle(e) {
    const newVal = e.target.options[e.target.selectedIndex].text;
    setUserConfigValue(this.cfgSTOREKEY, newVal);
    this._setStyle(newVal);
  }

  async _setStyle(name) {
    $(this.idCSS)?.remove();

    const contentC = $(this.cfgIDCONTENTCONTAINER);
    let cssClassPlus = this.config[this.activeSkin] || undefined;
    if (cssClassPlus)
      contentC.classList.remove(cssClassPlus);

    if (!name)
      return;

    const styleData = await storageSearch(STO_DATA, `${this.dirStyles}${name}.css`);
    appendCSS(this.idCSS, styleData);
    $(ID_MAINCSS_PLUS)?.remove();
    this.activeSkin = name;

    cssClassPlus = this.config[this.activeSkin] || undefined;
    if (cssClassPlus)
      contentC.classList.add(cssClassPlus);
  }

  onET_UserDataFileLoaded(evt) {
    if (!$(this.idCSS))
      this._setStyle(this.activeSkin);
  }
}

Plugins.catalogize(puiButtonSelectSkin);
