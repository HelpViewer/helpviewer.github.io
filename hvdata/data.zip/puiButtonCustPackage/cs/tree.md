# 📥 Vlastní balíček

- Vyberte požadované komponenty ze stromu níže (seznam odebratelných komponent aplikace)
- 📥 stáhne upravený archiv **hvdata/data.zip** jen s vybranými a základními součástmi aplikace
- 🔄 obrátí výběr
- Volba zůstane v paměti. Pro nový výběr obnovte stránku klávesou **F5**
