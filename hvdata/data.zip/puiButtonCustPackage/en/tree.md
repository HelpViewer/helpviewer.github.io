# 📥 Custom package download

- Select the desired components from the tree below (list of removable application components)
- 📥 downloads the modified archive **hvdata/data.zip** with only the selected and basic application components
- 🔄 reverses the selection
- The selection remains in memory. To make a new selection, refresh the page by pressing **F5**
