# 📄 Seznamy

Pro správné fungování aplikace HelpViewer jsou důležité následující seznamy:

- Seznam externích závislostí (deps.lst) (je použit pouze pro sestavení balíčku vydání)
- Seznam stylů (css.lst)
- Seznam skriptů (js.lst)
- Seznam pluginů (plugins.lst)

Seznamy řídí především co a v jakém pořadí se má z dat aplikace zavést.

Jejich popis naleznete v dalších podkapitolách.
