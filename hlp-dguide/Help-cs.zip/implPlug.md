# 🔧 Implementace pluginů

Následující kapitoly popisují implementaci jednotlivých typů pluginů, které jsou v systému obvyklé.
