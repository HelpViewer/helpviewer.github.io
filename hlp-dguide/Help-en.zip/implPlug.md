# 🔧 Plugin implementation

The following chapters describe the implementation of individual types of plugins that are common in the system.
