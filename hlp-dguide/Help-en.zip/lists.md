# 📄 Lists

The following lists are important for the proper functioning of the HelpViewer application:

- List of styles (css.lst)
- Script list (js.lst)
- Plugin list (plugins.lst)

The lists primarily control what data from the application is loaded and in what order.

Their description can be found in the following subchapters.
