const pluginWatermark = 'puiWatermark';
activatePlugin(pluginWatermark, 'toc', source = STO_HELP);
